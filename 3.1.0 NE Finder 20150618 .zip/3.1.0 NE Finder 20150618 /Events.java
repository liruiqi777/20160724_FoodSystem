import objectdraw.*;
import java.awt.*;
import java.util.Random;
import java.util.Arrays;

/**
 * 
 * Ruiqi Li
 * CIB Algorithm Coding
 * 
 * This version uses Updating Method 1.
 * It tells you how many scenarios will lead to a consistent scenario.
 *
 */

public class Events extends FrameWindowController {

    private int[] startingStatus = new int[15];
    private int[] inputStatus;
    private int[][] PAYOFF_MATRIX = new int[15][15];
    private Random generator;
    private int[][] updatedStatus = new int[243+1][15];
    // how to raise 3 to the fifth power in java

    public void begin(){
        int[][] PAYOFFMATRIX = {
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-1,0,1},
                {0,0,0,0,0,0,0,0,0,0,0,0,2,0,-2},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-2,0,2},
                {0,0,0,0,0,0,0,0,0,2,0,-2,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,-2,0,2,0,0,0},
                {3,0,-3,2,0,-2,2,0,-2,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {-3,0,3,0,0,0,-2,0,2,0,0,0,0,0,0},
                {2,0,-2,1,0,-1,-3,0,3,0,0,0,0,0,0},
                {0,0,0,0,0,0,-1,2,-1,0,0,0,0,0,0},
                {-2,0,2,-1,0,1,3,0,-3,0,0,0,0,0,0}
            };
        PAYOFF_MATRIX = PAYOFFMATRIX;

        System.out.println("The starting status is: " + Arrays.toString(startingStatus));
        System.out.println();
        // System.out.println("The payoff matrix is: ");
        // for (int i = 0; i < PAYOFF_MATRIX.length;i++){
        //     System.out.println(Arrays.toString(PAYOFF_MATRIX[i]));
        // }
        // System.out.println("");
    }

    public void onMouseClick(Location Point){
        int[] startingstatus = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int count = 0;
        for (int i = 0; i < 3; i++){
            startingstatus [i] = 1;
            for (int j = 0; j < 3; j++){
                startingstatus [j] = 1;
                for (int k = 0; k < 3; k++){
                    startingstatus [k] = 1;
                    for (int l = 0; l < 3; l++){
                        startingstatus [l] = 1;
                        for (int m = 0; m < 3; m++){
                            startingstatus [m] = 1;

                            for (int n = 0; n < updatedStatus.length; n++){
                                
                                for (int o = 0; o < startingStatus.length; o++){
                                    startingStatus[o] = startingstatus[o];
                                }

                                startingStatus = computeNextStatus (PAYOFF_MATRIX, startingStatus);

                                for (int p = 0; p < startingStatus.length; p++){
                                    updatedStatus[n][p] = startingStatus[p];
                                }

                                if (n == 0 && Arrays.equals(startingStatus, startingstatus)){
                                    n = updatedStatus.length;
                                    // System.out.println("You have reached a consistent scenarios after " + 0 + " rounds. The final consistent scenario is " + Arrays.toString(startingStatus));
                                    // System.out.println();
                                    // System.out.println();
                                    // System.out.println();
                                    count = count + 1;
                                }

                                for (int q = 0; q < n; q++) {
                                    if (updatedStatus[q] == startingStatus && q < n-1){
                                        // System.out.println("You cannot reach a consistent scenarios from the given starting status");
                                        // System.out.println();
                                        // System.out.println();
                                        // System.out.println();
                                        n = updatedStatus.length;
                                        q = n;
                                    } else if (Arrays.equals(updatedStatus[q], startingStatus) && q == n-1){
                                        // System.out.println("You have reached a consistent scenarios after " + i + " rounds. The final consistent scenario is " + Arrays.toString(startingStatus));
                                        // System.out.println();
                                        // System.out.println();
                                        // System.out.println();
                                        n = updatedStatus.length;
                                        q = n;
                                        count = count + 1;
                                    } else if (q == updatedStatus.length-1){
                                        // System.out.println("You cannot reach a consistent scenarios from the given starting status");
                                        // System.out.println();
                                        // System.out.println();
                                        // System.out.println();
                                        n = updatedStatus.length;
                                        q = n;
                                    }
                                }
                            }

                            startingstatus [m] = 0;
                        }
                        startingstatus [l] = 0;
                    }
                    startingstatus [k] = 0;
                }
                startingstatus [j] = 0;
            }
            startingstatus [i] = 0;
        }
        System.out.println("There are a total of " + count + " scenarios for this payoff matrix that lead to final consistent scenarios.");
    }

    private int[] computeNextStatus(int[][] PayoffMatrix, int[] StartingStatus){
        int[] nextRoundPayoff = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int localPayoff = 0;

        for (int i = 0; i < nextRoundPayoff.length; i++){
            localPayoff = 0;
            for (int j = 0; j < StartingStatus.length; j++){
                localPayoff = localPayoff + StartingStatus[j]*PayoffMatrix[j][i];
            }
            nextRoundPayoff[i] = localPayoff;
        }

        generator = new Random();

        for (int i = 0; i*3 + 3 <= nextRoundPayoff.length; i++){
            if (nextRoundPayoff[3*i + 0] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                StartingStatus [3*i + 0] = 1;
                StartingStatus [3*i + 1] = 0;
                StartingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 1] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                StartingStatus [3*i + 0] = 0;
                StartingStatus [3*i + 1] = 1;
                StartingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 2] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                StartingStatus [3*i + 0] = 0;
                StartingStatus [3*i + 1] = 0;
                StartingStatus [3*i + 2] = 1;
            } else if (nextRoundPayoff[3*i + 0] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (StartingStatus [3*i + 0] == findMax(StartingStatus [3*i + 0], StartingStatus [3*i + 1], StartingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        StartingStatus [3*i + 0] = 0;
                        StartingStatus [3*i + 1] = 1;
                        StartingStatus [3*i + 2] = 0;
                    } else {
                        StartingStatus [3*i + 0] = 0;
                        StartingStatus [3*i + 1] = 0;
                        StartingStatus [3*i + 2] = 1;
                    }
                }
            }else if (nextRoundPayoff[3*i + 1] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (StartingStatus [3*i + 1] == findMax(StartingStatus [3*i + 0], StartingStatus [3*i + 1], StartingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        StartingStatus [3*i + 0] = 1;
                        StartingStatus [3*i + 1] = 0;
                        StartingStatus [3*i + 2] = 0;
                    } else {
                        StartingStatus [3*i + 0] = 0;
                        StartingStatus [3*i + 1] = 0;
                        StartingStatus [3*i + 2] = 1;
                    }
                }
            } else if (nextRoundPayoff[3*i + 2] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (StartingStatus [3*i + 2] == findMax(StartingStatus [3*i + 0], StartingStatus [3*i + 1], StartingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        StartingStatus [3*i + 0] = 1;
                        StartingStatus [3*i + 1] = 0;
                        StartingStatus [3*i + 2] = 0;
                    } else {
                        StartingStatus [3*i + 0] = 0;
                        StartingStatus [3*i + 1] = 1;
                        StartingStatus [3*i + 2] = 0;
                    }
                }
            }
        }

        return StartingStatus;
    }

    private int findMax(int a, int b, int c){
        if (a>b && a>c){
            return a;
        }else if (b>a && b>c){
            return b;
        }else if (c>a && c>b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }

    private int findMin(int a, int b, int c){
        if (a<b && a<c){
            return a;
        }else if (b<a && b<c){
            return b;
        }else if (c<a && c<b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }

}