
import objectdraw.*;
import java.awt.*;
import java.util.Random;
import java.util.Arrays;

/**
 * Ruiqi Li
 * CIB Algorithm Coding
 * 
 * This version uses Updating Method 1.
 * It computes the next round action and gives you a notice when equilibrium is reached.
 */

public class Events extends FrameWindowController {

    private int[] startingStatus = new int[15];
    private int[] originalStatus = new int[15];
    private int[][] PAYOFF_MATRIX = new int[15][15];
    private int[] nextRoundPayoff = new int[15];
    private int localPayoff;
    private Random generator;

    public void begin(){
        int[] startingstatus = {1,0,0,1,0,0,1,0,0,0,0,1,1,0,0};
        startingStatus = startingstatus;
        int[][] PAYOFFMATRIX = {
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-1,0,1},
                {0,0,0,0,0,0,0,0,0,0,0,0,2,0,-2},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-2,0,2},
                {0,0,0,0,0,0,0,0,0,2,0,-2,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,-2,0,2,0,0,0},
                {3,0,-3,2,0,-2,2,0,-2,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {-3,0,3,0,0,0,-2,0,2,0,0,0,0,0,0},
                {2,0,-2,1,0,-1,-3,0,3,0,0,0,0,0,0},
                {0,0,0,0,0,0,-1,2,-1,0,0,0,0,0,0},
                {-2,0,2,-1,0,1,3,0,-3,0,0,0,0,0,0}
            };
        PAYOFF_MATRIX = PAYOFFMATRIX;

        System.out.println("The starting status is: " + Arrays.toString(startingStatus));
        System.out.println("");
        System.out.println("The payoff matrix is: ");
        for (int i = 0; i < PAYOFF_MATRIX.length;i++){
            System.out.println(Arrays.toString(PAYOFF_MATRIX[i]));
        }
        System.out.println("");
    }

    public void onMousePress(Location Point){

        for (int i = 0; i < nextRoundPayoff.length; i++){
            localPayoff = 0;
            for (int j = 0; j < startingStatus.length; j++){
                localPayoff = localPayoff + startingStatus[j]*PAYOFF_MATRIX[j][i];
            }
            nextRoundPayoff[i] = localPayoff;
        }
        System.out.println("The payoff of next round is: " + Arrays.toString(nextRoundPayoff));
        System.out.println("");

        generator = new Random();
        
        /* When there is a tie in maximum element and one of max is the original decision,
         * then action remains unchanged.
         * If the original decision is not one of the max,
         * then randomly choose from the other two decisions.
         */
        
        for (int i = 0; i*3 + 3 <= nextRoundPayoff.length; i++){
            if (nextRoundPayoff[3*i + 0] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 1;
                startingStatus [3*i + 1] = 0;
                startingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 1] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 0;
                startingStatus [3*i + 1] = 1;
                startingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 2] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 0;
                startingStatus [3*i + 1] = 0;
                startingStatus [3*i + 2] = 1;
            } else if (nextRoundPayoff[3*i + 0] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 0] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 1;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 1;
                    }
                }
            }else if (nextRoundPayoff[3*i + 1] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 1] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 1;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 1;
                    }
                }
            } else if (nextRoundPayoff[3*i + 2] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 2] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 1;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 1;
                        startingStatus [3*i + 2] = 0;
                    }
                }
            }
        }

        System.out.println("The updated status is : " + Arrays.toString(startingStatus));

        if (Arrays.equals(startingStatus, originalStatus)){
            System.out.println("Congratulations! You have reached an equilibrium!");
        }

        System.out.println("");
    }

    public void onMouseRelease (Location Point){
        for (int i = 0; i < startingStatus.length; i++){
            originalStatus[i] = startingStatus[i];
        }
        System.out.println("");
        System.out.println("");
        System.out.println("");
    }

    public int findMax(int a, int b, int c){
        if (a>b && a>c){
            return a;
        }else if (b>a && b>c){
            return b;
        }else if (c>a && c>b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }

    public int findMin(int a, int b, int c){
        if (a<b && a<c){
            return a;
        }else if (b<a && b<c){
            return b;
        }else if (c<a && c<b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }
}