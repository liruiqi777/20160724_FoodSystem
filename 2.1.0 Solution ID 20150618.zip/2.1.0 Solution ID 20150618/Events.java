import objectdraw.*;
import java.awt.*;
import java.util.Random;
import java.util.Arrays;

/**
 * Ruiqi Li
 * CIB Algorithm Coding
 * 
 * This version uses Updating Method 1.
 * It tells you if the starting status will lead to a consistent scenario.
 */

public class Events extends FrameWindowController {

    private int[] startingStatus = new int[15];
    private int[] inputStatus;
    private int[][] PAYOFF_MATRIX = new int[15][15];
    private Random generator;
    private int[][] updatedStatus = new int[243+1][15];
    // how to raise 3 to the fifth power in java

    public void begin(){
        int[] startingstatus = {0,1,0,0,1,0,0,1,0,0,1,0,0,1,0};
        inputStatus = startingstatus;
        for (int i = 0; i < startingstatus.length; i++){
            startingStatus[i] = startingstatus[i];
        }
        int[][] PAYOFFMATRIX = {
                {0,0,0,0,0,0,0,0,0,0,0,0,1,0,-1},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-1,0,1},
                {0,0,0,0,0,0,0,0,0,0,0,0,2,0,-2},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,-2,0,2},
                {0,0,0,0,0,0,0,0,0,2,0,-2,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,-2,0,2,0,0,0},
                {3,0,-3,2,0,-2,2,0,-2,0,0,0,0,0,0},
                {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                {-3,0,3,0,0,0,-2,0,2,0,0,0,0,0,0},
                {2,0,-2,1,0,-1,-3,0,3,0,0,0,0,0,0},
                {0,0,0,0,0,0,-1,2,-1,0,0,0,0,0,0},
                {-2,0,2,-1,0,1,3,0,-3,0,0,0,0,0,0}
            };
        PAYOFF_MATRIX = PAYOFFMATRIX;

        System.out.println("The starting status is: " + Arrays.toString(startingStatus));
        System.out.println();
        // System.out.println("The payoff matrix is: ");
        // for (int i = 0; i < PAYOFF_MATRIX.length;i++){
        //     System.out.println(Arrays.toString(PAYOFF_MATRIX[i]));
        // }
        // System.out.println("");
    }
    

    public void onMouseClick(Location Point){
        for (int i = 0; i < updatedStatus.length; i++) {
            startingStatus = computeNextStatus(PAYOFF_MATRIX, startingStatus);

            for (int k = 0; k < startingStatus.length; k++){
                updatedStatus[i][k] = startingStatus[k];
            }

            if (i == 0 && Arrays.equals(startingStatus, inputStatus)){
                i = updatedStatus.length;
                System.out.println("You have reached a consistent scenarios after " + 0 + " rounds. The final consistent scenario is " + Arrays.toString(startingStatus));
                System.out.println();
                System.out.println();
                System.out.println();
            }

            for (int j = 0; j < i; j++) {
                if (updatedStatus[j] == startingStatus && j < i-1){
                    System.out.println("You cannot reach a consistent scenarios from the given starting status");
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    i = updatedStatus.length;
                    j = i;
                } else if (Arrays.equals(updatedStatus[j], startingStatus) && j == i-1){
                    System.out.println("You have reached a consistent scenarios after " + i + " rounds. The final consistent scenario is " + Arrays.toString(startingStatus));
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    i = updatedStatus.length;
                    j = i;
                } else if (i == updatedStatus.length-1){
                    System.out.println("You cannot reach a consistent scenarios from the given starting status");
                    System.out.println();
                    System.out.println();
                    System.out.println();
                    i = updatedStatus.length;
                    j = i;
                }
            }
        }
    }

    private int[] computeNextStatus(int[][] payoffMatrix, int[] startingStatus){
        int[] nextRoundPayoff = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
        int localPayoff = 0;

        for (int i = 0; i < nextRoundPayoff.length; i++){
            localPayoff = 0;
            for (int j = 0; j < startingStatus.length; j++){
                localPayoff = localPayoff + startingStatus[j]*PAYOFF_MATRIX[j][i];
            }
            nextRoundPayoff[i] = localPayoff;
        }

        generator = new Random();

        for (int i = 0; i*3 + 3 <= nextRoundPayoff.length; i++){
            if (nextRoundPayoff[3*i + 0] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 1;
                startingStatus [3*i + 1] = 0;
                startingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 1] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 0;
                startingStatus [3*i + 1] = 1;
                startingStatus [3*i + 2] = 0;
            } else if (nextRoundPayoff[3*i + 2] == findMax(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                startingStatus [3*i + 0] = 0;
                startingStatus [3*i + 1] = 0;
                startingStatus [3*i + 2] = 1;
            } else if (nextRoundPayoff[3*i + 0] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 0] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 1;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 1;
                    }
                }
            }else if (nextRoundPayoff[3*i + 1] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 1] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 1;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 1;
                    }
                }
            } else if (nextRoundPayoff[3*i + 2] == findMin(nextRoundPayoff[3*i + 0], nextRoundPayoff[3*i + 1], nextRoundPayoff[3*i + 2])){
                if (startingStatus [3*i + 2] == findMax(startingStatus [3*i + 0], startingStatus [3*i + 1], startingStatus [3*i + 2])){
                    int randomDecision = generator.nextInt(1);
                    if (randomDecision == 0){
                        startingStatus [3*i + 0] = 1;
                        startingStatus [3*i + 1] = 0;
                        startingStatus [3*i + 2] = 0;
                    } else {
                        startingStatus [3*i + 0] = 0;
                        startingStatus [3*i + 1] = 1;
                        startingStatus [3*i + 2] = 0;
                    }
                }
            }
        }

        return startingStatus;
    }

    private int findMax(int a, int b, int c){
        if (a>b && a>c){
            return a;
        }else if (b>a && b>c){
            return b;
        }else if (c>a && c>b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }

    private int findMin(int a, int b, int c){
        if (a<b && a<c){
            return a;
        }else if (b<a && b<c){
            return b;
        }else if (c<a && c<b){
            return c;
        }else{
            return Math.abs(a)+Math.abs(b)+Math.abs(c)+1;
        }
    }

}